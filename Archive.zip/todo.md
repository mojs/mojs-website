# todo

- add spinner to the index
- publish projects to codepen and dribbble